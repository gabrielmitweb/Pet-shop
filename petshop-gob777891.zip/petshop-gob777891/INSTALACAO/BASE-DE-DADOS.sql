CREATE TABLE `admin` (
  `id` int(11) NOT NULL,
  `username` varchar(30) COLLATE utf8_unicode_ci DEFAULT NULL,
  `passcode` varchar(30) COLLATE utf8_unicode_ci DEFAULT NULL,
  `tipo` varchar(30) COLLATE utf8_unicode_ci DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `admin` (`id`, `username`, `passcode`, `tipo`) VALUES
(1, 'admin', 'admin', '1');

CREATE TABLE `atendimentos` (
  `id` int(11) NOT NULL,
  `pet` int(11) DEFAULT NULL,
  `tipo` int(11) DEFAULT NULL,
  `observacoes` text COLLATE utf8_unicode_ci,
  `parecer` text COLLATE utf8_unicode_ci,
  `situacao` text COLLATE utf8_unicode_ci
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `atendimentos` (`id`, `pet`, `tipo`, `observacoes`, `parecer`, `situacao`) VALUES
(7, 8, 7, 'Cuidado com a patinha', NULL, 'CONCLUIDO'),
(6, 8, 6, '', 'Tudo ok com o dog, retorno em 3 dias para parecer dos exames.', 'CONCLUIDO');

CREATE TABLE `donos` (
  `id` int(11) NOT NULL,
  `nome` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `endereco` text COLLATE utf8_unicode_ci,
  `telefone` text COLLATE utf8_unicode_ci
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `donos` (`id`, `nome`, `endereco`, `telefone`) VALUES
(6, 'Marcelo Nova', 'Av. Paulista, 200', '11 98888-7777');

CREATE TABLE `pets` (
  `id` int(11) NOT NULL,
  `nome` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `descricao` text COLLATE utf8_unicode_ci,
  `datanasc` date DEFAULT NULL,
  `tipo` text COLLATE utf8_unicode_ci,
  `dono` int(11) DEFAULT NULL,
  `sexo` text COLLATE utf8_unicode_ci
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `pets` (`id`, `nome`, `descricao`, `datanasc`, `tipo`, `dono`, `sexo`) VALUES
(8, 'Bolinha', 'Preto com manchas amarelas', NULL, 'Cachorro', 6, 'Macho');

CREATE TABLE `servicos` (
  `id` int(11) NOT NULL,
  `nome` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `descricao` text COLLATE utf8_unicode_ci,
  `tipo` text COLLATE utf8_unicode_ci,
  `preco` text COLLATE utf8_unicode_ci
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `servicos` (`id`, `nome`, `descricao`, `tipo`, `preco`) VALUES
(7, 'Banho', 'Banho do Pet', 'Atendimento CosmÃ©tico', '80,00'),
(6, 'Consulta BÃ¡sica', 'Consulta do Pet', 'Atendimento MÃ©dico', '100');

ALTER TABLE `admin`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `username` (`username`);

ALTER TABLE `atendimentos`
  ADD PRIMARY KEY (`id`);

ALTER TABLE `donos`
  ADD PRIMARY KEY (`id`);

ALTER TABLE `pets`
  ADD PRIMARY KEY (`id`);

ALTER TABLE `servicos`
  ADD PRIMARY KEY (`id`);

ALTER TABLE `admin`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

ALTER TABLE `atendimentos`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

ALTER TABLE `donos`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

ALTER TABLE `pets`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

ALTER TABLE `servicos`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;
COMMIT;