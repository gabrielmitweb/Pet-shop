<?php

$databaseHost = 'localhost';
$databaseName = 'USUARIOCPANEL_BANCO'; 
$databaseUsername = 'USUARIOCPANEL_USUARIOBANCO';
$databasePassword = 'SENHA';



$mysqli = mysqli_connect($databaseHost, $databaseUsername, $databasePassword, $databaseName); 


?>
