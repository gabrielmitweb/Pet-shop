<?php
// including the header file
include_once("header.php");
?>

  <title>Sobre</title>
  
  <style>
  body {  
      color: #f5f6f7;
  }
  p {font-size: 16px;}
  .margin {margin-bottom: 45px;}
  .bg-1 { 
      background-color: #666666;
      color: #ffffff;
  }
  .container-fluid {
      padding-top: 70px;
      padding-bottom: 70px;
  }

  </style>
</head>
<body>

<?php
// including the menu file
include_once("menu.php");
?>



<!-- First Container -->
<div class="container-fluid bg-1 text-center">
  <h3 class="margin">PetDo</h3>
  <img src="favicon.png" class="img-responsive img-circle margin" style="display:inline" alt="Dog" width="150" height="150">
  <h3>Sistema de gerenciamento PetDo!</h3>
</div>





</body>
</html>