
<?php
// including the header file
include_once("header.php");
?>

<title>Sistema de Gerenciamento PetDo</title>
</head>
<body>


<?php
// including the menu file
include_once("menu.php");
?>



	<div class="container">
		<div class="col-md-12">
			<h2>S</h2>
			<br><br>
			<h1 style="text-align: center">Bem-vindo ao Sistema de Gerenciamento PetDo</h1>
			<br><br>
			<img src="img/main.png" style="opacity: 0.5; display: block; margin: 0 auto;"/>
		</div>

	</div>
</body>
</html>